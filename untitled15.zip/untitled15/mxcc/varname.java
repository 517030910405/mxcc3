import java.util.*;
public class varname {
    public String name = "";// myInt/f()/b1b2b3/ etc
    public String type = "";// class/function/int etc
    //public HashMap<String, varname> namer = new HashMap<String, varname>();
    //If type is class then there is sub namespace
    public int array_dim = 0;
    public node location=null;//Maybe no need ?
    public boolean activate = false;
    //if function
}
